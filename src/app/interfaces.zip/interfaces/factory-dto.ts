export interface FactoryDTO {
    factoryId:number,
    factoryName:string,
    factoryLocation:string
}
