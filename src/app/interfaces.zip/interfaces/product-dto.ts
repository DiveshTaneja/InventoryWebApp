export interface ProductDTO {
    productId:number,
    quantity:number,
    productName:string
    description:string
}
