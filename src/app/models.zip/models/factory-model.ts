export class FactoryModel {
    factoryId:number;
    factoryName:string='';
    factoryLocation:string='';
}
